int x,y,z; float a;

int var(int-){
}


int main(){
	int a[2],c,i,j ; float d;
	int x-y,z;
	a = 2 + = 6
	#
	x = 2;
	
	a[0];
	a[1]=5;
	i= a[0]+a[1];
	j= 2*3+(5%3 < 4 && 8) || 2 ;
	d=var(1,2*3)+3.5*2;
	return 0;
}
