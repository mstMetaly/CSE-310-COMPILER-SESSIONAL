int x,y,z;
